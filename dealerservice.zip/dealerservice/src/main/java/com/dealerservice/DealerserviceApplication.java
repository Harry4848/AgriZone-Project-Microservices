package com.dealerservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DealerserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DealerserviceApplication.class, args);
	}

}
