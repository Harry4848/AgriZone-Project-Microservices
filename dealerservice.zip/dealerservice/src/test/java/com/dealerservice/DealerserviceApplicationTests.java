package com.dealerservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DealerserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
