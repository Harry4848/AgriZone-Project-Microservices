package com.farmerservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FarmerserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(FarmerserviceApplication.class, args);
	}

}
